<?php
/**
* 2015-2016 YDRAL.COM
*
* NOTICE OF LICENSE
*
*  @author    YDRAL.COM <info@ydral.com>
*  @copyright 2015-2016 YDRAL.COM
*  @license   GNU General Public License version 2
*
* You can not resell or redistribute this software.
*/

if (!defined('_PS_VERSION_')) {
    exit;
}
class AdminForms
{
    protected $serviplus_instance;
   /**
         * Constructor
         *
         * @param Correos $serviplus_instance needed for access to Module::l()
      */
    public function __construct($serviplus_instance)
    {
        if (!$serviplus_instance) {
            die("No Correos instance provided");
        }
        $this->serviplus_instance = $serviplus_instance;
    }

    public static function getHelperTabs()
    {
        $tabs = array(
            'general'  => array(
            'label' => 'General Configuration',
            'href'  => 'general',
            'icon'  => 'config_general.png',
            'sub_tab' => array(
                'empleados' => array(
                    'label' => 'Listado empleados',
                    'href'  => 'empleados',
                    'icon'  => 'account.png',
                )
                // 'altas'  => array(
                //     'label' => $this->serviplus_instance->trans('Altas', 'serviplusadminform'),
                //     'href'  => 'altas',
                //     'icon'  => 'service_urls.png',
                // ),
                // 'bajas'     => array(
                //     'label' => $this->serviplus_instance->trans('Bajas', 'serviplusadminform'),
                //     'href'  => 'bajas',
                //     'icon'  => 'presentation_mode.png',
                // ),
                // 'coordinadores'     => array(
                //     'label' => $this->serviplus_instance->trans('Coordinadores', 'serviplusadminform'),
                //     'href'  => 'coordinadores',
                //     'icon'  => 'pay_on_delivery.png',
                // ),
                // 'centros'     => array(
                //     'label' => $this->serviplus_instance->trans('Centros trabajo', 'serviplusadminform'),
                //     'href'  => 'centros',
                //     'icon'  => 'sender.png',
                // ),
                // 'intranet'     => array(
                //     'label' => $this->serviplus_instance->trans('Intranet serviplus', 'serviplusadminform'),
                //     'href'  => 'intranet',
                //     'icon'  => 'sender.png',
                //     )
                // ),
                // 'buzon'     => array(
                //     'label' => $this->serviplus_instance->trans('Buzón empleados', 'serviplusadminform'),
                //     'href'  => 'buzon',
                //     'icon'  => 'sender.png',
                //     )
                // )
                )
            )
        );
        
        return $tabs;
    }
    public function getHelperForm()
    {
        $tabs = $this->getHelperTabs();

        $empleados           = $this->getEmployedForm();
        // $altas               = $this->getAltasForm();
        // $bajas               = $this->getBajasForm();
        // $coordinadores       = $this->getCoordinadoresForm();
        // $centros             = $this->getCentrosForm();

        $form = array(
            'tabs'  => $tabs,
            'forms' => array(
                'empleados'         => $empleados
                // 'altas'             => $altas,
                // 'bajas'             => $bajas,
                // 'coordinadores'     => $coordinadores,
                // 'centros'           => $centros
                ),
            );
         
        return $form;
    }
    public function getEmployedForm()
    {

        $options = array(
            'seguridad_social' => array(
                'name'     => 'seguridad_social',
                'prefix'   => '',
                'label'    => 'User key',
                'type'     => 'textbox',
                // 'value'    => isset($serviplus_config['seguridad_social']) ? $serviplus_config['seguridad_social'] : '',
                'help'     => 'Without CE'
             ),
            // 'contract_number'   => array(
            //     'name'     => 'contract_number',
            //     'prefix'   => '',
            //     'label'    => $this->serviplus_instance->trans('Contract number', 'serviplusadminforms'),
            //     'type'     => 'textbox',
            //     'value'    => isset($serviplus_config['contract_number']) ? $serviplus_config['contract_number'] : ''
            // ),
            // 'client_number' => array(
            //     'name'     => 'client_number',
            //     'prefix'   => '',
            //     'label'    => $this->serviplus_instance->trans('Customer number', 'serviplusadminforms'),
            //     'type'     => 'textbox',
            //     'value'    => isset($serviplus_config['client_number']) ? $serviplus_config['client_number'] : '',
            //     'help'     => $this->serviplus_instance->trans('Without 99', 'serviplusadminforms')
            // ),
            // 'correos_user' => array(
            //     'name'     => 'correos_user',
            //     'prefix'   => '',
            //     'label'    => $this->serviplus_instance->trans('User', 'serviplusadminforms'),
            //     'type'     => 'textbox',
            //     'value'    => isset($serviplus_config['correos_user']) ? $serviplus_config['correos_user'] : ''
            // ),
            //     'correos_password' => array(
            //     'name'     => 'correos_password',
            //     'prefix'   => '',
            //     'label'    => $this->serviplus_instance->trans('Password', 'serviplusadminforms'),
            //     'type'     => 'textbox',
            //     'value'    => isset($serviplus_config['correos_password']) ? $serviplus_config['correos_password'] : ''
            // ),
            // 'correos_vuser' => array(
            //     'name'     => 'correos_vuser',
            //     'prefix'   => '',
            //     'label'    => $this->serviplus_instance->trans('Virtual Office User', 'serviplusadminforms'),
            //     'type'     => 'textbox',
            //     'value'    => isset($serviplus_config['correos_vuser']) ? $serviplus_config['correos_vuser'] : ''
            // ),
            // 'file_csv' => array(
            //     'name'     => 'file_csv',
            //     'prefix'   => '',
            //     'label'    => $this->serviplus_instance->trans('Import configuration data', 'serviplusadminforms'),
            //     'type'     => 'file'
            // )
        );

        $form = array(
            'tab'     => 'account',
            'title'   => 'Account details',
            'method'  => 'post',
            'enctype' => "multipart/form-data",
            'actions' => array(
                'save' => array(
                    'label' => 'Save',
                    'class' => 'save-general',
                    'icon'  => 'save',
                ),
            ),
            'options' => $options,
        );
         
        return $form;
    }
    public function getAltasForm($serviplus_config)
    {

        $options = array(
            'url_data' => array(
                'name'     => 'url_data',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('URL pre-register', 'serviplusadminforms'),
                'type'     => 'textbox',
                'value'    => $serviplus_config['url_data'],
                'help'     => $this->serviplus_instance->trans('Do not modify unless Correos say so', 'serviplusadminforms')
            ),
            'url_tracking' => array(
                'name'     => 'url_tracking',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('URL parcel tracking', 'serviplusadminforms'),
                'type'     => 'textbox',
                'value'    => $serviplus_config['url_tracking'],
                'help'     => $this->serviplus_instance->trans('Do not modify unless Correos say so', 'serviplusadminforms')
            ),
            'url_office_locator' => array(
                'name'     => 'url_office_locator',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('URL Correos office location', 'serviplusadminforms'),
                'type'     => 'textbox',
                'value'    => $serviplus_config['url_office_locator'],
                'help'     => $this->serviplus_instance->trans('Do not modify unless Correos say so', 'serviplusadminforms')
            ),
            'url_servicepaq' => array(
                'name'     => 'url_servicepaq',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('URL CityPaq', 'serviplusadminforms'),
                'type'     => 'textbox',
                'value'    => $serviplus_config['url_servicepaq'],
                'help'     => $this->serviplus_instance->trans('Do not modify unless Correos say so', 'serviplusadminforms')
            ),
            'url_collection' => array(
                'name'     => 'url_collection',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('URL Collection', 'serviplusadminforms'),
                'type'     => 'textbox',
                'value'    => isset($serviplus_config['url_collection']) ? $serviplus_config['url_collection']: '',
                'help'     => $this->serviplus_instance->trans('Do not modify unless Correos say so', 'serviplusadminforms')
            ),
            'api_google_key' => array(
                'name'     => 'api_google_key',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Google Maps Api Key', 'serviplusadminforms'),
                'type'     => 'textbox',
                'value'    => isset($serviplus_config['api_google_key']) ? $serviplus_config['api_google_key'] : '',
                'help'     => $this->serviplus_instance->trans('Needed if Google Maps returns error. Get Api Key from Google Developers web page', 'serviplusadminforms')
            )
        );
        $form = array(
            'tab'     => 'service_urls',
            'title'   => $this->serviplus_instance->trans('Service URLs', 'serviplusadminforms'),
            'method'  => 'post',
            'actions' => array(
                'save' => array(
                    'label' => $this->serviplus_instance->trans('Save', 'serviplusadminforms'),
                    'class' => 'save-general',
                    'icon'  => 'save',
                ),
            ),
            'options' => $options,
        );
         
        return $form;
    }
    public function getBajasForm($serviplus_config)
    {

        $options = array(
        'presentation_mode' => array(
            'name'     => 'presentation_mode',
            'prefix'   => '',
            'label'    => $this->serviplus_instance->trans(
                'Presentation mode for CityPaq and Office',
                'serviplusadminforms'
            ),
            'type'     => 'select',
            'default_option'    => isset($serviplus_config['presentation_mode']) ?
                $serviplus_config['presentation_mode'] : 'standard',
            'data'     => array(
                'standard' => $this->serviplus_instance->trans('Standard', 'serviplusadminforms'),
                'popup' => $this->serviplus_instance->trans('Pop-Up', 'serviplusadminforms')
                )
            )
        );

        $form = array(
            'tab'     => 'presentation_mode',
            'title'   => $this->serviplus_instance->trans('Presentation mode', 'serviplusadminforms'),
            'method'  => 'post',
            'actions' => array(
                'save' => array(
                    'label' => $this->serviplus_instance->trans('Save', 'serviplusadminforms'),
                    'class' => 'save-general',
                    'icon'  => 'save',
                ),
            ),
            'options' => $options,
        );

        return $form;
    }
    public function getCoordinadoresForm($serviplus_config)
    {
         
        $options = array(
            'bank_account_number' => array(
                    'name'     => 'bank_account_number',
                    'prefix'   => '',
                    'label'    => $this->serviplus_instance->trans('Bank account number / IBAN', 'serviplusadminforms'),
                    'type'     => 'textbox',
                    'value'    => isset($serviplus_config['bank_account_number']) ? $serviplus_config['bank_account_number'] : ''
                )
            ,
            'cashondelivery_modules' => array(
                    'name'     => 'cashondelivery_modules',
                    'prefix'   => '',
                    'label'    => $this->serviplus_instance->trans('Cash on delivery compatible modules', 'serviplusadminforms'),
                    'type'     => 'textbox',
                    'value'    => isset($serviplus_config['cashondelivery_modules']) ? $serviplus_config['cashondelivery_modules'] : '',
                    'help'     => $this->serviplus_instance->trans('Coma separated', 'serviplusadminforms')
                )
            );

            $form = array(
            'tab'     => 'pay_on_delivery',
            'title'   => $this->serviplus_instance->trans('Pay on delivery', 'serviplusadminforms'),
            'method'  => 'post',
            'actions' => array(
                'save' => array(
                    'label' => $this->serviplus_instance->trans('Save', 'serviplusadminforms'),
                    'class' => 'save-general',
                    'icon'  => 'save',
                ),
             ),
            'options' => $options,
        );

        return $form;
    }
    public function getCentrosForm($serviplus_config)
    {
        $sender_keys = preg_grep("/sender_/", array_keys($serviplus_config));
        $senders = array();
        $senders_select = array();
        foreach ($sender_keys as $sender_key) {
            $sender = Tools::jsonDecode($serviplus_config[$sender_key]);
            $senders[$sender_key] = $sender;
            $senders_select[$sender_key] = $sender->nombre != '' ?
                $sender->nombre . " " . $sender->apellidos : $sender->presona_contacto ;
        }
        $selected_sender = "sender_1";
        if (Tools::getValue('select_sender')) {
            $selected_sender = Tools::getValue('select_sender');
        }

        $options = array(
            'remove_sender' => array(
                'id'     => 'remove_sender',
                'value'    =>  $this->serviplus_instance->trans('Remove sender', 'serviplusadminforms'),
                'type'     => 'submit',
                'class'    => 'btn-primary'
            ),
            'add_sender' => array(
                'id'     => 'add_sender',
                'value'    =>  $this->serviplus_instance->trans('Add sender', 'serviplusadminforms'),
                'type'     => 'button',
                'class'    => 'btn-primary'
            ),
            'select_sender' => array(
                'name'     => 'select_sender',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Required fields', 'serviplusadminforms'),
                'label_class' => 'required',
                'type'     => 'select',
                'default_option'    => $selected_sender,
                'data'     => $senders_select,
                'help'     => $this->serviplus_instance->trans('Select sender', 'serviplusadminforms')
            ),
            'sender_default' => array(
                'name'     => 'sender_default',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Default Sender', 'serviplusadminforms'),
                'type'     => 'switch',
                'data'    => array(
                    '1' => $this->serviplus_instance->trans('Yes', 'serviplusadminforms'),
                    '0' => $this->serviplus_instance->trans('No', 'serviplusadminforms')),
                'default_option' => '0',
                'help'     => $this->serviplus_instance->trans('Set as default Sender (to show as first in the Senders list)', 'serviplusadminforms')
            ),
            'sender_nombre' => array(
                'name'     => 'sender_nombre',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Sender name', 'serviplusadminforms'),
                'label_class' => 'required',
                'type'     => 'textbox',
                'value'    => isset($senders[$selected_sender]->nombre) ? $senders[$selected_sender]->nombre : '',
                'help'     => $this->serviplus_instance->trans('Required if not filled Company+Contact person', 'serviplusadminforms')
            ),
            'sender_apellidos' => array(
                'name'     => 'sender_apellidos',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Sender surname', 'serviplusadminforms'),
                'label_class' => 'required',
                'type'     => 'textbox',
                'value'    => isset($senders[$selected_sender]->apellidos) ?
                    $senders[$selected_sender]->apellidos : '',
                'help'     => $this->serviplus_instance->trans('Required if not filled Company+Contact person', 'serviplusadminforms')
            ),
            'sender_dni' => array(
                'name'     => 'sender_dni',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('DNI', 'serviplusadminforms'),
                'label_class' => 'required',
                'value'    => isset($senders[$selected_sender]->dni) ? $senders[$selected_sender]->dni : '',
                'type'     => 'textbox'
            ),
            'sender_empresa' => array(
                'name'     => 'sender_empresa',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Sender company', 'serviplusadminforms'),
                'label_class' => 'required',
                'type'     => 'textbox',
                'value'    => isset($senders[$selected_sender]->empresa) ? $senders[$selected_sender]->empresa : '',
                'help'     => $this->serviplus_instance->trans('Required if not filled Sender name+Sender surname', 'serviplusadminforms')
            ),
            'sender_presona_contacto' => array(
                'name'     => 'sender_presona_contacto',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Contact person', 'serviplusadminforms'),
                'label_class' => 'required',
                'type'     => 'textbox',
                'value'    => isset($senders[$selected_sender]->presona_contacto) ?
                    $senders[$selected_sender]->presona_contacto : '',
                'help'     => $this->serviplus_instance->trans('Required if not filled Sender name+Sender surname', 'serviplusadminforms')
            )
            ,
            'sender_direccion' => array(
                'name'     => 'sender_direccion',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Address', 'serviplusadminforms'),
                'label_class' => 'required',
                'value'    => isset($senders[$selected_sender]->direccion) ?
                    $senders[$selected_sender]->direccion : '',
                'type'     => 'textbox'
            ),
            'sender_localidad' => array(
                'name'     => 'sender_localidad',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('City', 'serviplusadminforms'),
                'label_class' => 'required',
                'value'    => isset($senders[$selected_sender]->transocalidad) ?
                    $senders[$selected_sender]->transocalidad : '',
                'type'     => 'textbox'
            ),
            'sender_cp' => array(
                'name'     => 'sender_cp',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Postal Code', 'serviplusadminforms'),
                'label_class' => 'required',
                'value'    => isset($senders[$selected_sender]->cp) ? $senders[$selected_sender]->cp : '',
                'type'     => 'textbox'
            ),
            'sender_provincia' => array(
                'name'     => 'sender_provincia',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Province', 'serviplusadminforms'),
                'label_class' => 'required',
                'value'    => isset($senders[$selected_sender]->provincia) ?
                    $senders[$selected_sender]->provincia : '',
                'type'     => 'textbox'
            ),
            'sender_tel_fijo' => array(
                'name'     => 'sender_tel_fijo',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Land line', 'serviplusadminforms'),
                'value'    => isset($senders[$selected_sender]->tel_fijo) ?
                    $senders[$selected_sender]->tel_fijo : '',
                'type'     => 'textbox'
            ),
            'sender_movil' => array(
                'name'     => 'sender_movil',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Mobile phone', 'serviplusadminforms'),
                'value'    => isset($senders[$selected_sender]->movil) ? $senders[$selected_sender]->movil : '',
                'type'     => 'textbox'
            ),
            'sender_email' => array(
                'name'     => 'sender_email',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('E-mail', 'serviplusadminforms'),
                'value'    => isset($senders[$selected_sender]->email) ? $senders[$selected_sender]->email : '',
                'type'     => 'textbox'
            ),
            'senders_json' => array(
                'id'     => 'senders_json',
                'prefix'   => '',
                'value'    =>  Tools::jsonEncode($senders),
                'type'     => 'hidden'
            )
        );

        if (count($sender_keys) <= 1 &&
            empty($senders[$selected_sender]->direccion) &&
            empty($senders[$selected_sender]->transocalidad) &&
            empty($senders[$selected_sender]->cp) &&
            empty($senders[$selected_sender]->provincia)
        ) {
            unset($options['add_sender']);
            unset($options['remove_sender']);
        }
        if (count($sender_keys) == 0) {
            unset($options['select_sender']);
        }
        $form = array(
            'tab'     => 'sender',
            'title'   => $this->serviplus_instance->trans('Sender', 'serviplusadminforms'),
            'class'   => 'sender',
            'method'  => 'post',
            'actions' => array(
                'save' => array(
                    'label' => $this->serviplus_instance->trans('Save', 'serviplusadminforms'),
                    'class' => 'save-general',
                    'icon'  => 'save',
                    ),
            ),
            'options' => $options,
        );
         
        return $form;
    }
    public function getMultiShipmentForm($serviplus_config)
    {
        $options = array(
            'multishipment' => array(
                'name'     => 'multishipment',
                'prefix'   => '',
                'label'    => $this->serviplus_instance->trans('Active Multi shipment', 'serviplusadminforms'),
                'type'     => 'switch',
                'default_option'    => $serviplus_config['multishipment'] == 1 ? "on" : "off",
                'data'     => array(
                    "on" => $this->serviplus_instance->trans('Yes', 'serviplusadminforms'),
                    "off" => $this->serviplus_instance->trans('No', 'serviplusadminforms')),
                'help'    => $this->serviplus_instance->trans(
                    'Orders with different products, will generate label for each warehouse',
                    'serviplusadminforms'
                )
            )
        );

        $form = array(
            'tab'     => 'multi_shipment',
            'title'   => $this->serviplus_instance->trans('Multi Shipment', 'serviplusadminforms'),
            'method'  => 'post',
            'actions' => array(
                'save' => array(
                    'label' => $this->serviplus_instance->trans('Save', 'serviplusadminforms'),
                    'class' => 'save-general',
                    'icon'  => 'save',
                ),
            ),
            'options' => $options,
        );

        return $form;
    }
}
