<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since   1.5.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

include_once(__DIR__ . '/classes/Empleado.php');
include_once(__DIR__ . '/classes/Coordinador.php');
include_once(__DIR__ . '/controllers/admin/AdminForm.php');

class Serviplus extends Module implements WidgetInterface
{
    protected $_html = '';
    protected $templateFile;

    public function __construct()
    {
        $this->name = 'serviplus';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Roanja';
        $this->need_instance = 0;
        $this->secure_key = Tools::encrypt($this->name);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->getTranslator()->trans('Management Serviplus system', array(), 'Modules.Serviplus.Admin');
        $this->description = $this->getTranslator()->trans('Online resources management and planning system.', array(), 'Modules.Serviplus.Admin');
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);

        $this->templateFile = 'module:serviplus/views/templates/hook/serviplus.tpl';

        $this->initList();
    }

    /**
     * @see Module::install()
     */
    public function install()
    {
        /* Adds Module */
        if (parent::install() &&
            $this->registerHook('displayHeader') &&
            $this->registerHook('displayHome') &&
            $this->registerHook('actionShopDataDuplication')
        ) {
            $shops = Shop::getContextListShopID();
            $shop_groups_list = array();

            /* Setup each shop */
            foreach ($shops as $shop_id) {
                $shop_group_id = (int)Shop::getGroupFromShop($shop_id, true);

                if (!in_array($shop_group_id, $shop_groups_list)) {
                    $shop_groups_list[] = $shop_group_id;
                }

                $res = Configuration::updateValue('SERVIPLUS_VERSION', $this->version, false, $shop_group_id, $shop_id);

            } 

            if (count($shop_groups_list)) {
                foreach ($shop_groups_list as $shop_group_id) {
                    $res &= Configuration::updateValue('SERVIPLUS_VERSION', $this->version, false, $shop_group_id); 
                } 
            }

            $res &= Configuration::updateValue('SERVIPLUS_VERSION', $this->version);

            $res &= $this->createTables();

            $this->installTab('AdminParentTabServiplus', 'Serviplus Configuration'); 
            $this->installTab('AdminServiplusEmpleado', 'Datos extras', 'AdminParentCustomer');
            $this->installTab('AdminServiplusCoordinador', 'Coordinadores', 'AdminParentCustomer');
            // $this->installTab('AdminMipServiciosTipo', 'Types of services', 'AdminParentTabServiplus');
            // $this->installTab('AdminMipPrioridadTipo', 'Types of priority', 'AdminParentTabServiplus');
            
            $this->installTab('AdminServiplusModule', 'Configuration', 'AdminParentCustomer');

            return (bool)$res;
        }

        return false;
    }

    public function installTab($className, $tabName, $tabParentName = false)
    {
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = $className;
        $tab->name = array();

        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = $tabName;
        }
        if ($tabParentName) {
            $tab->id_parent = (int)Tab::getIdFromClassName($tabParentName);
        } else {
            $tab->id_parent = 0;
        }
        
        $tab->module = $this->name;
        return $tab->add();
    }

    /**
    * @see Module::uninstall()
    */
    public function uninstall()
    {
        /* Deletes Module */
        if (parent::uninstall()) {
            /* Deletes tables */
            $res = $this->deleteTables();

            /* Unsets configuration */
            $res &= Configuration::deleteByName('MIPLANNING_VERSION');
            $res &= $this->uninstallTab('AdminParentTabServiplus');
            $res &= $this->uninstallTab('AdminServiplusModule');
            $res &= $this->uninstallTab('AdminServiplusEmpleado');
            $res &= $this->uninstallTab('AdminServiplusCoordinador');
            // $res &= $this->uninstallTab('AdminMipServiciosTipo');
            // $res &= $this->uninstallTab('AdminMipPrioridadTipo');

            return (bool)$res;
        }

        return false;
    }

    public function uninstallTab($tabName = '')
    {
        //$tab_class = Tools::ucfirst($this->name) . Tools::ucfirst($class_sfx);
        $id_tab    = Tab::getIdFromClassName($tabName);
        if ($id_tab != 0) {
            $tab = new Tab($id_tab);
            $tab->delete();
            return true;
        }
    }

     /**
     * Creates tables
     */
    protected function createTables()
    {
        // Install SQL
        $sql = array();
        include dirname(__FILE__) . '/sql/sql-install.php';
        foreach ($sql as $s) {
            if (!Db::getInstance()->Execute($s)) {
                return false;
            }
        }
        return true;
    }

     /**
     * deletes tables
     */
    protected function deleteTables()
    {
        return Db::getInstance()->execute('
            DROP TABLE IF EXISTS 
                `'._DB_PREFIX_.'serviplus_empleado`,
                `'._DB_PREFIX_.'serviplus_empleado_shop`,
                `'._DB_PREFIX_.'serviplus_coordinador`,
                `'._DB_PREFIX_.'serviplus_coordinador_shop`,
                `'._DB_PREFIX_.'serviplus_nacionalidades`;              
        ');
    }

    public function getContent()
    {

        if (Tools::isSubmit('updateserviplus_empleado') || Tools::isSubmit('addserviplus_empleado')) {
            $this->_html .= $this->renderFormEmpleados();
            $this->_html .= $this->listAltas();
            $this->_html .= $this->listBajas();
        } else {
            // $content = $this->getListContent();
            // $helper = $this->initList();
            // $helper->listTotal = count($content);
            // $this->_html .= $helper->generateList($content, $this->fields_list);

            $this->_html .= $this->initList();
        }

        return $this->_html;
    }

    protected function getListContent()
    {
        return  Db::getInstance()->executeS('
            SELECT cl.`id_empleado`, cl.`seguridad_social` 
            FROM `' . _DB_PREFIX_ . 'serviplus_empleado` cl');
    }

    protected function initList()
    {
        // $nacionalidades = $this->getNacionalidades();
        // foreach ($nacionalidades as $nacionalidad) {
        //     $this->nacionalidad_array[$nacionalidad['codigo']] = $nacionalidad['nacionalidad'];
        // }

        // $coordinadores = Coordinador::getCoordinador();
        // foreach ($coordinadores as $coordinador) {
        //     $this->coordinadores_array[$coordinador['id_coordinador']] = $coordinador['firstname'];
        // }

        $fields_list = array(
            'id_empleado' => array(
                'title' => $this->trans('ID', array(), 'Admin.Global'),
                'width' => 120,
                'class' => 'fixed-width-xs',
                'type' => 'text',
                'search' => true,
                'orderby' => true
            ),
            'seguridad_social' => array(
                'title' => $this->trans('Text', array(), 'Admin.Global'),
                'width' => 140,
                'type' => 'text',
                'search' => true,
                'orderby' => true,
                'tmpTableFilter' => true
            ),
        );
        

        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->identifier = 'id_empleado';
        $helper->actions = array('edit', 'delete');
        $helper->show_toolbar = true;
        $helper->toolbar_btn['new'] =  array(
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&add'.$this->name.'_empleado&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->trans('Add new', array(), 'Admin.Actions')
        );

        $helper->title = $this->displayName;
        $helper->table = $this->name . '_empleado';
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        $content = $this->getListContent();        
        $helper->listTotal = count($content);
        return $helper->generateList($content, $fields_list);
    }

    protected function listAltas()
    {
        // $nacionalidades = $this->getNacionalidades();
        // foreach ($nacionalidades as $nacionalidad) {
        //     $this->nacionalidad_array[$nacionalidad['codigo']] = $nacionalidad['nacionalidad'];
        // }

        // $coordinadores = Coordinador::getCoordinador();
        // foreach ($coordinadores as $coordinador) {
        //     $this->coordinadores_array[$coordinador['id_coordinador']] = $coordinador['firstname'];
        // }

        $fields_list = array(
            'id_empleado' => array(
                'title' => $this->trans('ID', array(), 'Admin.Global'),
                'width' => 120,
                'class' => 'fixed-width-xs',
                'type' => 'text',
                'search' => true,
                'orderby' => true
            ),
            'seguridad_social' => array(
                'title' => $this->trans('Text', array(), 'Admin.Global'),
                'width' => 140,
                'type' => 'text',
                'search' => true,
                'orderby' => true,
                'tmpTableFilter' => true
            ),
        );
        

        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->identifier = 'id_empleado';
        $helper->actions = array('edit', 'delete');
        $helper->show_toolbar = true;
        $helper->toolbar_btn['new'] =  array(
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&add'.$this->name.'_altas&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->trans('Add new', array(), 'Admin.Actions')
        );

        $helper->title = $this->displayName;
        $helper->table = $this->name . '_empleado';
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        $content = $this->getListContent();        
        $helper->listTotal = count($content);
        return $helper->generateList($content, $fields_list);
        // return $helper;
    }

    protected function listBajas()
    {
        // $nacionalidades = $this->getNacionalidades();
        // foreach ($nacionalidades as $nacionalidad) {
        //     $this->nacionalidad_array[$nacionalidad['codigo']] = $nacionalidad['nacionalidad'];
        // }

        // $coordinadores = Coordinador::getCoordinador();
        // foreach ($coordinadores as $coordinador) {
        //     $this->coordinadores_array[$coordinador['id_coordinador']] = $coordinador['firstname'];
        // }

        $fields_list = array(
            'id_empleado' => array(
                'title' => $this->trans('ID', array(), 'Admin.Global'),
                'width' => 120,
                'class' => 'fixed-width-xs',
                'type' => 'text',
                'search' => true,
                'orderby' => true
            ),
            'seguridad_social' => array(
                'title' => $this->trans('Text', array(), 'Admin.Global'),
                'width' => 140,
                'type' => 'text',
                'search' => true,
                'orderby' => true,
                'tmpTableFilter' => true
            ),
        );
        

        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->identifier = 'id_empleado';
        $helper->actions = array('edit', 'delete');
        $helper->show_toolbar = true;
        $helper->toolbar_btn['new'] =  array(
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&add'.$this->name.'_bajas&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->trans('Add new', array(), 'Admin.Actions')
        );

        $helper->title = $this->displayName;
        $helper->table = $this->name . '_empleado';
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        $content = $this->getListContent();        
        $helper->listTotal = count($content);
        return $helper->generateList($content, $fields_list);
        // return $helper;
    }

    protected function displayForm($helper_form)
    {
        $params_back = array(
            'CORREOS_TPL'       => _PS_ROOT_DIR_.'/modules/'.$this->name.'/',
            'HELPER_FORM' => $helper_form
        );

        $this->smarty->assign('paramsBack', $params_back);
        $this->_html .= $this->display(__FILE__, 'views/templates/admin/form.tpl');
    }

    public function renderFormEmpleados()
    {          
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->getTranslator()->trans('Employed information', array(), 'Modules.Serviplus.Admin'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->getTranslator()->trans('Sefuridad social', array(), 'Modules.Serviplus.Admin'),
                        'name' => 'seguridad_social',
                        'required' => true
                    )
                ),
                'submit' => array(
                    'title' => $this->getTranslator()->trans('Save', array(), 'Admin.Actions'),
                )
            ),
        );

        
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $this->fields_form = array();
        $helper->module = $this;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitEmpleado';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getAddFieldsValues(),
        );

        return $helper->generateForm(array($fields_form));
    }

    public function getAddFieldsValues()
    {
        $fields = array();

        if (Tools::isSubmit('id_empleado') && $this->empleadoExists((int)Tools::getValue('id_empleado'))) {
            $empleado = new Empleado((int)Tools::getValue('id_empleado'));
            $fields['id_empleado'] = (int)Tools::getValue('id_empleado', $empleado->id);
        } 

        return $fields;
    }

    public function empleadoExists($id_empleado)
    {
        $req = 'SELECT c.`id_customer` as id_empleado
                FROM `'._DB_PREFIX_.'customer` c';
        $row = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow($req);

        return ($row);
    }

    public function renderWidget($hookName = null, array $configuration = [])
    {
        if (!$this->isCached($this->templateFile, $this->getCacheId())) {
            $this->smarty->assign($this->getWidgetVariables($hookName, $configuration));
        }

        return $this->fetch($this->templateFile, $this->getCacheId());
    }

    public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        return ['serviplus' => "Hola serviplus!"];
    }
}